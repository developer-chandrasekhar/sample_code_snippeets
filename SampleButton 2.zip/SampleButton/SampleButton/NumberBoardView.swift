//
//  NumberBoardView.swift
//  SampleButton
//
//  Created by Chandra Sekhar P V on 30/10/22.
//

import UIKit
import SnapKit

class NumberBoardView: UIView {
    
    private var numbersArray: [UIView] = []
    
    static var coinWidth: CGFloat = {
        let screenWidth = UIScreen.main.bounds.width
        let spaceBetweenNumbers = 3.0
        let numberWidth = (screenWidth - 40 - (8.0 * spaceBetweenNumbers))/9.0
        return numberWidth
    }()
    
    static var viewHeight: CGFloat = {
       let spaceBetweenNumbers = 3.0
        let height = 11.0 * NumberBoardView.coinWidth + (10.0 * spaceBetweenNumbers)
       return height
   }()
    
    private var numberWidth = {
        return NumberBoardView.coinWidth
    }()
    
    var numberView: UIView {
        let view = UIView()
        return view
    }
    
    var coinImageView: UIImageView {
        let imageView = UIImageView()
        imageView.tag = 101
        return imageView
    }
    
    var numberLabel: UILabel {
        let label = UILabel()
        label.backgroundColor = UIColor.lightGray.withAlphaComponent(0.2)
        label.layer.masksToBounds = true
        label.layer.cornerRadius = numberWidth/2
        label.font = UIFont.systemFont(ofSize: 24)
        label.textAlignment = .center
        label.textColor = UIColor.lightGray.withAlphaComponent(0.2)
        label.tag = 102
        return label
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.layout()
        }
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func updateNumber(number: Int) {
        if let numView = self.numbersArray.filter({$0.tag == number}).first, let imageView = numView.viewWithTag(101) as? UIImageView, let label = numView.viewWithTag(102) as? UILabel {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                label.textColor = .black
                label.font = UIFont.boldSystemFont(ofSize: 24)
                imageView.image = UIImage(named: "coin_yellow_final")
            }
        }
    }
}

extension NumberBoardView {
    private func layout() {
        var x = 0.0
        var y = 0.0
        var tag = 1
        
        for i in 1...9 {
            for j in 1...11 {
                if i == 1 && j > 9 { break }
                if i != 9 && j > 10 { break }
                
                let view = numberView
                let label = numberLabel
                let imageView = coinImageView
                
                self.addSubview(view)
                view.addSubview(imageView)
                imageView.addSubview(label)
                
                view.tag = tag
                label.text = "\(tag)"
                numbersArray.append(view)
                
                view.snp.makeConstraints { make in
                    make.left.equalTo(x)
                    make.top.equalTo(y)
                    make.width.height.equalTo(numberWidth)
                }
                
                imageView.snp.makeConstraints { make in
                    make.edges.equalToSuperview()
                }
                
                label.snp.makeConstraints { make in
                    make.edges.equalToSuperview()
                }
                y = y + numberWidth + 3.0
                tag += 1
            }
            y = 0
            x = x + numberWidth + 3.0
        }
    }
}

