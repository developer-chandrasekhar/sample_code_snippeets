//
//  GenerateTicket.swift
//  SampleButton
//
//  Created by Chandra Sekhar P V on 26/10/22.
//

import Foundation

typealias TicketLayout = [Int: Int]

class GenerateTicket {
    
    private var numberSets: [[Int]] = []
    
    func tickets(with count: Int = 6) -> [TicketLayout] {
        numberSets = self.generateNumberSets()
        return self.generateTickets(with: count)
    }
}

extension GenerateTicket {
    
    private func generateTickets(with numberOfTickets: Int) -> [TicketLayout] {
        var ticketlayouts: [TicketLayout] = []
        for _ in 1...numberOfTickets {
            let randomFifteenNumbers = getRandomFifteen()
            let layout = self.processRandomFiteenNumbers(numbers: randomFifteenNumbers)
            ticketlayouts.append(layout)
        }
        return ticketlayouts
    }
    
    private func processRandomFiteenNumbers(numbers: [Int]) -> TicketLayout {
        
        var unProcessedNumbers = numbers
        var numberLayout: TicketLayout = [:]
         
        for row in 1...3 {
            if row == 3 {
                unProcessedNumbers.forEach { number in
                    
                    switch number {
                    case 1...9:
                        numberLayout[3] = number
                    case 80...90:
                        numberLayout[27] = number
                    default:
                        let colid = number/10
                        numberLayout[colid*3+3] = number
                    }
                }
                continue
            }
            
            var filledPlacesForRow = 0
            var placedNumbers: [Int] = []
            
            if row == 2 {
                for i in 0...8 {
                    print("2nd row filledPosition verification: \(i)")
                    if numberLayout[(i*3)+2] != nil {
                        filledPlacesForRow += 1
                        print("2nd row filledPosition: \(i)")
                    }
                }
            }
            for i in 0...8 {
                var columnRange = 1...2
                if i == 0 { columnRange = 1...9 }
                else if i == 8 { columnRange = 80...90 }
                else { columnRange = i*10...((i+1)*10)-1 }
                
                let colNumbers = unProcessedNumbers.filter { columnRange ~= $0 }
                if colNumbers.count == 3 {
                    numberLayout[(i*3)+1] = colNumbers[0]
                    numberLayout[(i*3)+2] = colNumbers[1]
                    numberLayout[(i*3)+3] = colNumbers[2]
                    filledPlacesForRow += 1
                    placedNumbers.append(contentsOf: colNumbers)
                }
                else if colNumbers.count == 2 && row == 2 {
                    numberLayout[(i*3)+2] = colNumbers[0]
                    numberLayout[(i*3)+3] = colNumbers[1]
                    filledPlacesForRow += 1
                    placedNumbers.append(contentsOf: colNumbers)
                }
            }
            
            var availablePalcesForRow: [Int] = []
            
            for i in 0...8 {
                let val = numberLayout[i*3 + row]
                guard val == nil else {
                    continue
                }
                
                var columnRange = 1...2
                if i == 0 { columnRange = 1...9 }
                else if i == 8 { columnRange = 80...90 }
                else { columnRange = i*10...((i+1)*10)-1 }
                let availableNumbers = unProcessedNumbers.filter { columnRange ~= $0 }
                if availableNumbers.count > 0 {
                    availablePalcesForRow.append(i)
                }
            }
            // filledPlacesForRow = 5 means already row filled
            if filledPlacesForRow == 5 {
                continue
            }
            var numberRandomPlace: [Int] = []
            if availablePalcesForRow.count == 5 - filledPlacesForRow {
                numberRandomPlace = availablePalcesForRow
            }
            else {
                 numberRandomPlace = givemeRandomPositions(maxPositions: 5-filledPlacesForRow, from: availablePalcesForRow)
            }
            
            let remainingNumbers = unProcessedNumbers.filter({!placedNumbers.contains($0)})
            
            availablePalcesForRow.forEach { place in
                if numberRandomPlace.contains(place) {
                    var columnRange = 1...9
                    if place == 0 { columnRange = 1...9 }
                    else if place == 8 { columnRange = 80...90 }
                    else { columnRange = place*10...((place+1)*10)-1 }
                    
                    if let colNumber = remainingNumbers.filter({ columnRange ~= $0 }).first {
                        numberLayout[(place*3)+row] = colNumber
                        placedNumbers.append(colNumber)
                    }
                }
            }
            // Remove placed numbers from unprocessed numbers
            unProcessedNumbers.removeAll(where: {placedNumbers.contains($0)})
        }
        return numberLayout
    }
}

extension GenerateTicket {
    
    //Generate random 15 numbers form sets, pick a random number from each set
    private func getRandomFifteen() -> [Int] {
        var randomFifteen: [Int] = []
        for (i, numberSet) in numberSets.enumerated() {
            var duplicateSet = numberSet
            if let randomnumber = duplicateSet.randomElement() {
                randomFifteen.append(randomnumber)
                if let numberIndex = duplicateSet.firstIndex(of: randomnumber) {
                    duplicateSet.remove(at: numberIndex)
                    numberSets[i] = duplicateSet
                }
            }
        }
        return randomFifteen
    }
    
    //Generate 15 number sets with range of 6, ex: 1 to 6, 7 to 12, .... 85 to 90
    private func generateNumberSets() -> [[Int]] {
        var setsArray: [[Int]] = []
        var startNumber = 1
        for i in 1...15 {
            setsArray.append([Int](startNumber...i*6))
            startNumber = i*6+1
        }
        return setsArray
    }
}

func givemeRandomPositions(maxPositions: Int, from positions: [Int]) -> [Int] {
    var set: Set<Int> = Set([])
    while set.count < maxPositions {
        if let element = positions.randomElement() {
            set.insert(element)
        }
    }
    return Array(set).sorted(by: < )
}

extension Int {
    static func getUniqueRandomNumbers(min: Int, max: Int, count: Int, exclude: [Int] = []) -> [Int] {
        var set: Set<Int> = Set(exclude)
        while set.count < count {
            set.insert(Int.random(in: min...max))
        }
        return Array(set).sorted(by: > )
    }
}
