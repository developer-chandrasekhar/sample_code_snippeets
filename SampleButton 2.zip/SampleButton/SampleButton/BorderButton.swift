//
//  BorderButton.swift
//  SampleButton
//
//  Created by Chandra Sekhar P V on 20/10/22.
//

import UIKit
import SnapKit

class Ticket: UIView {
    
    struct Constants {
        enum color {
            case lineColor
            var value: UIColor {
                switch self {
                case .lineColor: return .black
                }
            }
        }
    }
    
    var separatorView: UIView {
        let view = UIView()
        view.backgroundColor = Constants.color.lineColor.value
        return view
    }
    
    init(draw frame: CGRect, bgColor: UIColor, with numbers: TicketLayout) {
        super.init(frame: frame)
        self.backgroundColor = bgColor
        self.addOutline()
        self.addSeparators()
        self.addNumbers(layout: numbers)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func addOutline() {
        self.layer.masksToBounds = true
        self.layer.cornerRadius = 0.0
        self.layer.borderColor = Constants.color.lineColor.value.cgColor
        self.layer.borderWidth = 0.5
    }
    
    private func addSeparators() {
        
        for i in 1...2 {
            let view = separatorView
            self.addSubview(view)
            view.snp.makeConstraints { make in
                make.left.right.equalToSuperview()
                make.height.equalTo(0.5)
                make.top.equalTo(self.frame.size.height/3*CGFloat(integerLiteral: i))
            }
        }
        
        for i in 1...8 {
            let view = separatorView
            self.addSubview(view)
            view.snp.makeConstraints { make in
                make.top.bottom.equalToSuperview()
                make.width.equalTo(0.5)
                make.left.equalTo(self.frame.size.width/9*CGFloat(integerLiteral: i))
            }
        }
    }
    
    private func addNumbers(layout: TicketLayout) {
        
        var left: CGFloat = 0
        var top: CGFloat = 0
        var index = 1
        let w: CGFloat = self.frame.size.width/9
        let h: CGFloat = self.frame.size.height/3
        
        for _ in 1...9 {
            for j in 1...3 {
                if let value = layout[index] {
                    let label = UILabel(frame: CGRect(x: left, y: top, width: w, height: h))
                    label.backgroundColor = .clear
                    label.text = "\(value)"
                    label.font = UIFont.boldSystemFont(ofSize: 22)
                    label.textAlignment = .center
                    self.addSubview(label)
                }
                index += 1
                if j == 3 {
                    top = 0
                } else {
                    top += h
                }
            }
            left += w
        }
    }
}




