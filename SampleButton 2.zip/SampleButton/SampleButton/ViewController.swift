//
//  ViewController.swift
//  SampleButton
//
//  Created by Chandra Sekhar P V on 20/10/22.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        let ticketLayouts = GenerateTicket().tickets()
        let ticketsView = TicketsView(with: ticketLayouts)
        self.view = ticketsView
    }
}

