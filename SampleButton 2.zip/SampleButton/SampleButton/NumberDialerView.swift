//
//  NumberDialer.swift
//  SampleButton
//
//  Created by Chandra Sekhar P V on 31/10/22.
//

import UIKit

class NumberDialerView: UIView {
    
    let screenWidth = UIScreen.main.bounds.width
    let timeIntervalBetweenNumbers: Double = 5 // 5 sec
    
    public var currentNumber: (Int) -> Void = { _ in}
    public var numberBoardTapped: () -> Void = { }
    
    var viewNumberBoardButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "number-block"), for: .normal)
        return button
    }()
    
    var palyPauseButton: UIButton = {
        let button = UIButton()
        button.setTitle("Play", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.layer.borderColor = UIColor.orange.cgColor
        button.layer.borderWidth = 2.0
        button.layer.masksToBounds = true
        return button
    }()
    
    var isGamePaused = true
    var pickNumberLock = false

    var previousNumberView: UIView?
    var currentNumberView: UIView?
    
    var currentNumberLabel: UILabel {
        let label = UILabel()
        label.backgroundColor = .clear
        label.textColor = .black
        label.textAlignment = .center
        label.tag = 102
        label.font = UIFont.boldSystemFont(ofSize: 44)
        return label
    }
    
    var numberView: UIView {
        let view = UIView()
        view.layer.borderColor = UIColor.black.cgColor
        view.layer.masksToBounds = true
        return view
    }
    
    var coinImageView: UIImageView {
        let imageView = UIImageView(image: UIImage(named: "coin_yellow_final"))
        imageView.tag = 101
        return imageView
    }
    
    init(with frame: CGRect = .zero) {
        super.init(frame: frame)
        self.backgroundColor = .clear
        self.addViewNumberBoardButton()
        self.addPlayPauseButton()
        self.addCurrentNumberView()
        self.addPreviousNumberView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func numberBoardButtonTapped(sender: UIButton) {
        self.numberBoardTapped()
    }
    
    @objc func playPauseButtonTapped(sender: UIButton) {
        isGamePaused = !isGamePaused
        self.pickNextNumber()
    }
}

extension NumberDialerView {
    
    private func addViewNumberBoardButton() {
        addSubview(viewNumberBoardButton)
        viewNumberBoardButton.addTarget(self, action: #selector(numberBoardButtonTapped(sender:)), for: .touchUpInside)
        viewNumberBoardButton.snp.makeConstraints { make in
            make.right.equalToSuperview().inset(20)
            make.width.height.equalTo(54)
            make.centerY.equalToSuperview()
        }
    }
    
    private func addPlayPauseButton() {
        self.addSubview(palyPauseButton)
        palyPauseButton.addTarget(self, action: #selector(playPauseButtonTapped(sender:)), for: .touchUpInside)
        palyPauseButton.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(20)
            make.width.height.equalTo(54)
            make.centerY.equalToSuperview()
        }
        palyPauseButton.layoutIfNeeded()
        palyPauseButton.layer.cornerRadius = palyPauseButton.frame.size.width*0.5
        
    }
    
    private func addCurrentNumberView() {
        currentNumberView = prepareNumberView(with: 0, font: UIFont.boldSystemFont(ofSize: 44))
        currentNumberView?.isHidden = true
    }
    
    private func addPreviousNumberView() {
        previousNumberView = prepareNumberView(with: 0, font: UIFont.boldSystemFont(ofSize: 22))
        previousNumberView!.snp.remakeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.width.equalTo(40)
            make.right.equalTo(self.viewNumberBoardButton.snp.left).inset(-24)
        }
        previousNumberView?.isHidden = true
    }
    
    private func prepareNumberView(with number: Int, font: UIFont) -> UIView {
        let view = numberView
        let label = currentNumberLabel
        let imageView = coinImageView
        
        label.text = "\(number)"
        label.font = font
        self.addSubview(view)
        view.addSubview(imageView)
        imageView.addSubview(label)
        
        view.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.height.equalTo(80)
        }
        
        imageView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        label.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        return view
    }
}

extension NumberDialerView {
    
    private func pickNextNumber() {
        if isGamePaused || pickNumberLock { return }
        pickNumberLock = true
        guard let number = (1...90).randomElement(), let currentNumberView = currentNumberView, let label = currentNumberView.viewWithTag(102) as? UILabel  else { return }
        currentNumberView.isHidden = false
        currentNumberView.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        label.text = "\(number)"
        animateCurrentNumberView(view: currentNumberView)
        currentNumber(number)
    }
    
    private func animateCurrentNumberView(view: UIView) {
        UIView.animate(withDuration: 1, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut,animations: {
            view.transform = CGAffineTransformIdentity
        },completion: { c in
            UIView.animate(withDuration: 1, delay: self.timeIntervalBetweenNumbers - 1.5, options: UIView.AnimationOptions.curveEaseOut,animations: {
                view.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
            },completion: { c in
                self.moveToPreviousNumber()
            })
        })
    }
    
    private func moveToPreviousNumber() {
        
        guard let previousNumberView = previousNumberView else { return }
        guard let currentNumberView = currentNumberView else { return }
        guard let currentNumberLabel = currentNumberView.viewWithTag(102) as? UILabel,
              let previousNumberLabel = previousNumberView.viewWithTag(102) as? UILabel else { return }
        
        let previousNumberViewCenter = previousNumberView.center
        let currentNumberViewCenter = currentNumberView.center
        
        UIView.animate(withDuration: 0.5, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut,animations: {
            previousNumberView.center = self.viewNumberBoardButton.center
            currentNumberView.center = previousNumberViewCenter
            previousNumberView.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        },completion: { finish in
            previousNumberView.center = previousNumberViewCenter
            currentNumberView.center = currentNumberViewCenter
            previousNumberView.isHidden = false
            previousNumberView.transform = .identity
            previousNumberLabel.text = currentNumberLabel.text
            currentNumberView.transform = CGAffineTransform(scaleX: 0.0, y: 0.0)
            self.pickNumberLock = false
            self.pickNextNumber()
        })
    }
}

