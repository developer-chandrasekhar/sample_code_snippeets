//
//  NumberBoardView.swift
//  SampleButton
//
//  Created by Chandra Sekhar P V on 30/10/22.
//

import UIKit
import SnapKit

class NumberBoardView: UIView {
    
    private var numbersArray: [UILabel] = []
    
    static var coinWidth: CGFloat = {
        let screenWidth = UIScreen.main.bounds.width
        let spaceBetweenNumbers = 3.0
        let numberWidth = (screenWidth - 40 - (8.0 * spaceBetweenNumbers))/9.0
        return numberWidth
    }()
    
    static var viewHeight: CGFloat = {
       let spaceBetweenNumbers = 3.0
       // 20 -> 10 * 2 -> 10 is the top bottom, left, right
        let height = 11.0 * NumberBoardView.coinWidth + (10.0 * spaceBetweenNumbers)
       return height
   }()
    
    private var numberWidth = {
        return NumberBoardView.coinWidth
    }()
    
    var numberLabel: UILabel {
        let label = UILabel()
        label.backgroundColor = UIColor.lightGray.withAlphaComponent(0.4)
        label.layer.masksToBounds = true
        label.layer.cornerRadius = numberWidth/2
        label.font = UIFont.systemFont(ofSize: 20)
        label.textAlignment = .center
        label.textColor = .lightGray
        return label
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.layout()
            if let l = self.numbersArray.filter({$0.tag == 66}).first {
                DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                    l.textColor = .darkText
                    l.font = UIFont.boldSystemFont(ofSize: 20)
                }
            }
        }
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension NumberBoardView {
    private func layout() {
        var x = 0.0
        var y = 0.0
        var tag = 1
        
        for i in 1...9 {
            for j in 1...11 {
                if i == 1 && j > 9 { break }
                if i != 9 && j > 10 { break }

                let label = numberLabel
                self.addSubview(label)
                label.tag = tag
                label.text = "\(tag)"
                numbersArray.append(label)
                label.snp.makeConstraints { make in
                    make.left.equalTo(x)
                    make.top.equalTo(y)
                    make.width.height.equalTo(numberWidth)
                }
                y = y + numberWidth + 3.0
                tag += 1
            }
            y = 0
            x = x + numberWidth + 3.0
        }
    }
}

