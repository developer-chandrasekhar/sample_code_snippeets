//
//  TicketsView.swift
//  SampleButton
//
//  Created by Chandra Sekhar P V on 27/10/22.
//

import UIKit
import SnapKit

/*
 const colors = [
   'azure',
   'honeydew',
   'lavenderblush',
   'ivory',
   'aliceblue',
   'seashell'
 ];
 
 */


class TicketsView: UIView {
    
    var scrollView: UIScrollView = {
        let view = UIScrollView()
        return view
    }()
    
    var ticketColor: UIColor = {
        //return UIColor(red: 255.0/255.0, green: 240.0/255.0, blue: 245.0/255.0, alpha: 1.0)
        return UIColor(red: 240.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0)

        let r = Double((250...255).randomElement() ?? 220)
        let g = Double((240...250).randomElement() ?? 240)
        let b = Double((240...255).randomElement() ?? 250)
        return UIColor(red: r/255.0, green: g/255.0, blue: b/255.0, alpha: 1.0)
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init(with tickets: [TicketLayout]) {
        super.init(frame: .zero)
        self.backgroundColor = ticketColor
        self.drawLayout(with: tickets)

    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension TicketsView {
    
    private func drawLayout(with tickets: [TicketLayout]) {
        
        let window = UIApplication.shared.windows.first
        let topPadding = window!.safeAreaInsets.top
        let bottomPadding = window!.safeAreaInsets.bottom
        
        let numberDailerView = NumberDialer()
        self.addSubview(numberDailerView)
        self.addSubview(scrollView)
        numberDailerView.snp.makeConstraints { make in
            make.top.equalTo(topPadding + 20)
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(120)
        }
        scrollView.snp.makeConstraints { make in
            make.top.equalTo(numberDailerView.snp.bottom)
            make.leading.trailing.bottom.equalToSuperview()
            //make.height.equalTo(tickets.count * 100)
        }
        self.drawTickets(tickets: tickets)
    }
    
    private func drawTickets(tickets: [TicketLayout]) {
        var top = 0.0
        let screenWidth = UIScreen.main.bounds.width
        let ticketWidth = screenWidth - 40.0
        let ticketHeight = (ticketWidth/9) * 3
        let ticketX = 20.0
        for i in 0..<tickets.count {
            let ticketFrame = CGRect(x: ticketX, y: top, width: ticketWidth , height: ticketHeight)
            let ticket = Ticket(draw: ticketFrame, bgColor: ticketColor, with: tickets[i])
            scrollView.addSubview(ticket)
            top += ticketHeight + 40.0
            if i != (tickets.count - 1) {
                let separator = UIView(frame: CGRect(x: ticketX, y: top-20, width: ticketWidth, height: 0.5))
                separator.backgroundColor = .clear
                separator.drawDottedLine()
                scrollView.addSubview(separator)
            }
            else {
                let numberBoard = NumberBoardView(frame: CGRect(x: ticketX, y: top, width: ticketWidth, height: NumberBoardView.viewHeight))
                scrollView.addSubview(numberBoard)
                
            }
        }
        scrollView.contentSize.height = CGFloat(top + NumberBoardView.viewHeight)
    }
}

extension UIView {
    func drawDottedLine() {
        let shapeLayer = CAShapeLayer()
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.lineWidth = 0.5
        shapeLayer.lineDashPattern = [7, 3] // 7 is the length of dash, 3 is length of the gap.

        let path = CGMutablePath()
        path.addLines(between: [CGPoint(x: bounds.minX, y: bounds.minY), CGPoint(x: bounds.maxX, y: bounds.minY)])
        shapeLayer.path = path
        layer.addSublayer(shapeLayer)
    }
}
