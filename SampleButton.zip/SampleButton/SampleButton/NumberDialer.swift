//
//  NumberDialer.swift
//  SampleButton
//
//  Created by Chandra Sekhar P V on 31/10/22.
//

import UIKit

class NumberDialer: UIView {
    
    let screenWidth = UIScreen.main.bounds.width
    let timeIntervalBetweenNumbers: Double = 5 // 5 sec

    var viewNumberBoardButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "number-block"), for: .normal)
        return button
    }()
    
    var palyPauseButton: UIButton = {
        let button = UIButton()
        button.setTitle("Play", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.layer.borderColor = UIColor.orange.cgColor
        button.layer.borderWidth = 2.0
        button.layer.masksToBounds = true
        return button
    }()
    
    var recentNumberView: UIView = {
        let view = UIView(frame: CGRect(x: 1, y: 1, width: 0, height: 44))
        view.backgroundColor = .clear
        return view
    }()
    
    var recentNumberArray: [UILabel] = []
    
    var previousNumberLabel: UILabel?
    var currentNumberLabelCopy: UILabel?
    
    var currentNumberLabel: UILabel {
        let label = UILabel()
        label.layer.masksToBounds = true
        label.backgroundColor = .white
        label.textColor = .black
        label.layer.borderColor = UIColor.black.cgColor
        label.layer.borderWidth = 2.0
        label.textAlignment = .center
        label.font = UIFont.boldSystemFont(ofSize: 44)
        return label
    }
    
    init(with frame: CGRect = .zero) {
        super.init(frame: frame)
        self.backgroundColor = .clear
        self.addViewNumberBoardButton()
        self.addPlayPauseButton()
        self.addCurrentNumber()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension NumberDialer {
    private func addViewNumberBoardButton() {
        self.addSubview(viewNumberBoardButton)
        viewNumberBoardButton.snp.makeConstraints { make in
            make.right.equalToSuperview().inset(20)
            make.width.height.equalTo(54)
            make.centerY.equalToSuperview()
        }
    }
    
    private func addPlayPauseButton() {
        self.addSubview(palyPauseButton)
        palyPauseButton.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(20)
            make.width.height.equalTo(54)
            make.centerY.equalToSuperview()
        }
        palyPauseButton.layoutIfNeeded()
        palyPauseButton.layer.cornerRadius = palyPauseButton.frame.size.width*0.5

    }
    
    private func addCurrentNumber() {
        let label = currentNumberLabel
        let n = (1...90).randomElement()
        label.text = "\(n!)"
        self.addSubview(label)
        label.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.height.equalTo(80)
        }
        label.layoutIfNeeded()
        label.layer.cornerRadius = label.frame.size.width*0.5
        label.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        self.animateCurrentNumber(numberLabel: label)
    }
}

extension NumberDialer {
    
    private func animateCurrentNumber(numberLabel: UILabel) {
        UIView.animate(withDuration: 1, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut,animations: {
            numberLabel.transform = CGAffineTransformIdentity
        },completion: { c in
            UIView.animate(withDuration: 1, delay: self.timeIntervalBetweenNumbers - 1.5, options: UIView.AnimationOptions.curveEaseOut,animations: {
                numberLabel.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
            },completion: { c in
                self.animateCurrentNumberToPreviousNumber(numberLabel: numberLabel)
            })
        })
    }
    
    private func animateCurrentNumberToPreviousNumber(numberLabel: UILabel) {
        var previousNumberLabelCenter = numberLabel.center
        previousNumberLabelCenter.x = numberLabel.center.x + (self.viewNumberBoardButton.center.x - numberLabel.center.x)/2

        if let previousNumberLabel = previousNumberLabel {
            UIView.animate(withDuration: 0.5, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut,animations: {
                previousNumberLabel.center = self.viewNumberBoardButton.center
                previousNumberLabel.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
            },completion: { c in
                previousNumberLabel.removeFromSuperview()
            })
        }
        UIView.animate(withDuration: 0.5, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut,animations: {
            numberLabel.center = previousNumberLabelCenter
        },completion: { c in
            self.addPreviousNumber(center: previousNumberLabelCenter, currentlabel: numberLabel)
            self.addCurrentNumber()
            numberLabel.removeFromSuperview()
        })
    }
    
    private func addPreviousNumber(center: CGPoint, currentlabel: UILabel) {
        let label = currentNumberLabel
        label.text = currentlabel.text
        label.font = UIFont.boldSystemFont(ofSize: 22)
        previousNumberLabel = label
        addSubview(label)
        previousNumberLabel?.snp.makeConstraints({ make in
            make.width.height.equalTo(40)
            make.center.equalTo(center)
        })
        label.layoutIfNeeded()
        label.layer.cornerRadius = label.frame.size.width*0.5
        label.layer.borderWidth = 1.0
    }
}

